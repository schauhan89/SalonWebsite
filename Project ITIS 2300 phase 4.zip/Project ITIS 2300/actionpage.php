<html>
<body>
<head>
 <style>
            body {background-color:black}
            h1   {color:brown}
            h2   {color:brown}
            h3  {color:brown}
            li {color: yellowgreen}
            p    {color:yellowgreen}
            th {color: yellowgreen}
            tr {color: yellowgreen}
            a {color: white}


        </style>
</head>
<a href="home.html"><img src = "home.png" height = "50" width="50"></a><br>

<p align=center >Thank you! You Have Been Subscribed! 

<?php echo $_POST[ "first_name" ]; ?><br>

Your email address is Saved: <?php  echo $_POST[ "email" ]; ?>

</body>
</html>