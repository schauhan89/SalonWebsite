Phase4: Final Phase

The following were added to enhance the webpage:
1)Jquery.js for Animation schemes on the HomePage such as the fade in fade out method, Dropdown banner.Home page buttom with anchor**    <a href="home.html"><img src = "home.png" height = "50" width="50"></a><br>

2) For the contactus.html file animation using hover function. 

3) Gallery: photos.html added fadeIn fadeOut with timing feature to the first row using hover.
4) CSS external sheet and inline reference used to format and color the webscheme.
 